// Paste your Supabase project URL and anon (public) key here.
// Leave them empty to run in demo mode: data is kept in your browser only.
// The anon key is safe to publish; row-level security in supabase/schema.sql limits what it can do.
window.SS_CONFIG = {
  supabaseUrl: "",
  supabaseAnonKey: "",
  // A/B test on the claim button wording. Each user is assigned an arm permanently.
  experiment: {
    name: "claim_cta_v1",
    arms: { A: "Claim a portion", B: "Save me one" }
  }
};
